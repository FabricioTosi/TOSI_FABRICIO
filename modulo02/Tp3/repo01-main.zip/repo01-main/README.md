# alumno: Tosi Fabricio Rafael 
## Este readme.md esta echo para dar un resumen de la tarea que consiste en 5 ejercicios utilizando Github Web que son los siguiuentes:
### Ejercicio: 1)
En este ejercicio se debe crear una cuenta en la plataforma Github Web la cual se debe cargar una foto de perfil del usuario que la va a utilizar.

### Ejercicio: 2)
El ejercicio 2 consiste en 4 puntos que son los siguientes:

a) Crear un repositorio privado llamado “repo01”.

b) Desde la interfaz web crear un archivo README.md que contenga el autor (su nombre y apellido
completo) y una descripción de la tarea. Luego realizar un “commit” de dichos cambios.

c) Crear una carpeta llamada “carpeta”, adentro crear el archivo “script.js”. Luego realizar un commit en
la rama “main” con una descripción del punto.

d) Editar el archivo script.js y agregar: // Este es un archivo de pruebas. Luego realizar un commit en la
rama “main” con una descripción del punto.

### Ejercicio: 3)
En el ejercicio 3 se deben realizar los siguentes 2 puntos:

a) Crear un nuevo repositorio público en github.com que tenga de nombre el del estudiante (ejemplo:
Perez_Juan).

b) En el repositorio, crear un archivo README.md, ingresar los siguientes datos utilizando el formato
Markdown:

o Título: Curso de programación full stack
o Subtítulo: Comisión A o B según corresponda
o Encabezado: Silicon Misiones - https://siliconmisiones.gob.ar/
o Autor: nombre y apellido del estudiante
o Descripción: este repositorio fue creado con fines académicos. Contiene los ejercicios
resueltos del Módulo 1.

### Ejercicio: 4)
Este ejerciocio se realiza de la siguiente forma:

a) En el repositorio “apellido_nombre” crear el siguiente árbol de carpetas:

a. /modulo01/tp1

b. /modulo01/tp2

c. /modulo02

b) En cada directorio agregar las consignas de los trabajos en formato PDF. Por ejemplo: en la carpeta
tp2 deberán agregar el archivo PDF del trabajo practico N°2.

### Ejercicio: 5)

En el repositorio público “apellido_nombre” subir los ejercicios resueltos de los trabajos realizados a
la fecha. Quedando ordenado de la siguiente manera: modulo${numModulo}/tp${numTP}/ejercicio-
${numEjercicio}.

Por ejemplo: /modulo01/tp1/ejercicio-2.js
